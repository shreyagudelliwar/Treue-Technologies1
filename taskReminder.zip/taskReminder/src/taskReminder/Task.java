package taskReminder;

import java.time.LocalDate;

public class Task {
	
	private String name;
	private LocalDate  dueDate;
	private String categoey;
	private  int priority;
	private boolean isComlpleted;
	
	public Task(String name, LocalDate dueDate, String categoey, int priority) {
		
		this.name = name;
		this.dueDate = dueDate;
		this.categoey = categoey;
		this.priority = priority;
		this.isComlpleted = false;
	}
	
	public boolean isCompleted() {
		return isCompleted() ;
		
	}
	 public void setCompleted(boolean completed) {
		  boolean isCompleted = completed; 
	 }

	public String getName() {
		return name;
	}

	

	public LocalDate getDueDate() {
		return dueDate;
	}

	

	public String getCategoey() {
		return categoey;
	}

	

	public int getPriority() {
		return priority;
	}
}

	
	
	 
	
	
	
	
	
	
