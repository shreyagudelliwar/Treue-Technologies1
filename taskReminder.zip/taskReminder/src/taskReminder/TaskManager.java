package taskReminder;

import java.util.ArrayList;
import java.util.List;

public class TaskManager {
	
	private List<Task> tasks;
	
	public TaskManager() {
		this.tasks = new ArrayList<>();
		
	}
	 public void addTask(Task task)
	 {
		 tasks.add(task);
	 }
	 public void markTaskAsCompleted(int index) {
		 if(index>=0&& index<tasks.size()) {
			 tasks.get(index).setCompleted(true);
			  }
	 }
	 public Task getTask(int index){
		 if(index>=0&& index < tasks.size()) {
		return tasks.get(index);
		 
	 }
		 return null;
	 
	 }
	  public int getTaskCount()
	  {
		  return tasks.size();
	  }

}
